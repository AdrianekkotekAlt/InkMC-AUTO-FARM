# MADE BY ADRIANEKKOTEK
# MADE BY ADRIANEKKOTEK


import pyautogui
import time
from pynput.keyboard import Listener, Key

# Function to hold a key for a specified duration
def hold_key(key, duration):
    pyautogui.keyDown(key)
    time.sleep(duration)
    pyautogui.keyUp(key)

# Wait for 3 seconds before starting the actions
time.sleep(3)

# Move the mouse to the specified coordinates
pyautogui.moveTo(950, 550)

# Function to stop the script when F4 is pressed
def on_press(key):
    if key == Key.f4:
        return False

# Start listening for the F4 key press
with Listener(on_press=on_press) as listener:
    # Infinite loop
    while listener.running:
        # Hold left mouse button down
        pyautogui.mouseDown(button='left')
        
        # Hold 'D' key for 1.8 seconds
        hold_key('d', 2)
        
        # Hold 'A' key for 1.8 seconds
        hold_key('a', 2)
        
        # Release left mouse button
        pyautogui.mouseUp(button='left')


# MADE BY ADRIANEKKOTEK

